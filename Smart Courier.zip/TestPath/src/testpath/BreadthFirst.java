/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author USER
 */
public class BreadthFirst extends Test {

    @Override
    public void run() {
        Queue<Cell> queue = new LinkedList<>();
        Cell current, tmp;
        queue.add(sumber);
        try {
            while (!queue.isEmpty() && !stateJalur) {
                Thread.sleep(Model.THREAD_SLEEP_TIME);
                {
                    current = queue.poll();

                    if (current.state != StateCell.SUMBER)
                        FXMLDocumentController.paintCell(current.x, current.y, Model.BORDER, Model.JALUR);
                    
                    for (int i = 0; i < Model.JUMLAH_SISI_CELL && !stateJalur; i++) {
                        if (inRange(current.x + X[i], current.y + Y[i])) {

                            tmp = FXMLDocumentController.CellDenah[current.x + X[i]][current.y + Y[i]];

                            if (tmp.state == StateCell.DESTINASI || tmp.state == StateCell.BLANK) {
                                tmp.setParent(current.x, current.y);


                                if (tmp.state != StateCell.DESTINASI)
                                    FXMLDocumentController.paintCell(tmp.x, tmp.y, Model.BORDER, Model.JALUR2);
                                else {
                                    tracePath(tmp);
                                    stateJalur = true;
                                    break;
                                }

                                FXMLDocumentController.CellDenah[tmp.x][tmp.y].state = StateCell.JALUR;
                                queue.add(tmp);
                            }
                        }
                    }
                }
            } if (!stateJalur) {
                stopThread();
            }
        } catch (Exception e) {

        }

    }

    public void tracePath(Cell cell) {
        LinkedList<Cell> shortestPath = new LinkedList<Cell>();
        while (cell.state != StateCell.SUMBER) {
            shortestPath.addFirst(cell);
            cell = FXMLDocumentController.CellDenah[cell.parent_x][cell.parent_y];
        }
        colorPath(shortestPath, Model.RUTE_JALUR, true);
        stopThread();
        
    }
    
}
