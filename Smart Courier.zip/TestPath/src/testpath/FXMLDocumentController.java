/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author USER
 */
public class FXMLDocumentController extends Test implements Initializable {

    @FXML
    private GridPane platform;
    @FXML
    private AnchorPane gridContainer;
    @FXML
    private Button startButton;
    @FXML
    private Button mazeButton;

    public static BorderPane[][] BorderCell = new BorderPane[Model.ROW][Model.COL];
    public static Cell[][] CellDenah = new Cell[Model.ROW][Model.COL];
    private int[][] stateJenisCell = new int[2][2];
    private StateCell stateCell;
    private boolean warna;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        for (int x = 0; x < Model.ROW; x++) {
            for (int y = 0; y < Model.COL; y++) {
                CellDenah[x][y] = new Cell(x, y);
                constructCell(x, y);
            }
        }
        for (int i = 0; i < 2; i++) {
            stateJenisCell[i][0] = -1;
        }
        stateCell = null;
        warna = false;

        ChangeListener<Number> changeListener = (observable, oldVal, newVal) -> gridUpdate();

        gridContainer.heightProperty().addListener(changeListener);
        gridContainer.widthProperty().addListener(changeListener);
    }

    public void gridUpdate() {
        double containerWidth = gridContainer.getWidth();
        double containerHeight = gridContainer.getHeight();

        double gridCellWidth = containerWidth / Model.COL;
        double gridCellHeight = containerHeight / Model.ROW;

        double gridCellSize = Math.min(gridCellWidth, gridCellHeight);

        double gridWidth = gridCellSize * Model.COL;
        double gridHeight = gridCellSize * Model.ROW;

        double marginTopBottom = (containerHeight - gridHeight) / 2;
        double marginLeftRight = (containerWidth - gridWidth) / 2;

        platform.setPadding(new Insets(marginTopBottom, marginLeftRight, marginTopBottom, marginLeftRight));
    }


    private void constructCell(int x, int y) {
        BorderPane tmpPane = new BorderPane();
        tmpPane.setPrefSize(Model.CELL_WIDTH, Model.CELL_HEIGHT);
        tmpPane.setStyle("-fx-border-color: " + Model.BORDER + "; -fx-background-color: " + Model.BLANK + ";");
        platform.add(tmpPane, y, x);
        BorderCell[x][y] = tmpPane;

        tmpPane.setOnMouseEntered(e -> {
            if (stateCell == StateCell.BLOCK) {
                if (CellDenah[x][y].state != StateCell.SUMBER && CellDenah[x][y].state != StateCell.DESTINASI && warna) {
                    tmpPane.setStyle("-fx-border-color: " + Model.BORDER + "; -fx-background-color: " + Model.BLOCK + ";");
                    CellDenah[x][y].state = StateCell.BLOCK;
                }
            }

            if (stateCell == StateCell.BLANK) {
                if (CellDenah[x][y].state != StateCell.SUMBER && CellDenah[x][y].state != StateCell.DESTINASI && warna) {
                    tmpPane.setStyle("-fx-border-color: " + Model.BORDER + "; -fx-background-color: " + Model.JALUR + ";");
                    CellDenah[x][y].state = StateCell.BLANK;
                    CellDenah[x][y].count = 0;
                }
            }
        });

        tmpPane.setOnMouseClicked(e -> {
            System.out.println("stat " + getstate());
            if (getstate() == false) {
                System.out.println("aaaa");
            } else {
                state = true;
                System.out.println("vvvv");
                if (e.getButton() == MouseButton.PRIMARY) {
                    if (CellDenah[x][y].state == StateCell.SUMBER) {
                        blankCell(0);
                    } else if (CellDenah[x][y].state == StateCell.BLANK) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.SUMBER;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.SUMBER);
                    } else if (CellDenah[x][y].state == StateCell.RUTE_JALUR) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.SUMBER;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.SUMBER);
                    } else if (CellDenah[x][y].state == StateCell.JALUR) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.SUMBER;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.SUMBER);
                    } else if (CellDenah[x][y].state == StateCell.JALUR2) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.SUMBER;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.SUMBER);
                    }
                } else if (e.getButton() == MouseButton.SECONDARY) {
                    if (CellDenah[x][y].state == StateCell.DESTINASI) {
                        blankCell(1);
                    } else if (CellDenah[x][y].state == StateCell.BLANK) {
                        blankCell(1);
                        CellDenah[x][y].state = StateCell.DESTINASI;
                        stateJenisCell[1][0] = x;
                        stateJenisCell[1][1] = y;
                        paintCell(x, y, Model.BORDER, Model.DESTINASI);
                    } else if (CellDenah[x][y].state == StateCell.RUTE_JALUR) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.DESTINASI;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.DESTINASI);
                    } else if (CellDenah[x][y].state == StateCell.JALUR) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.DESTINASI;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.SUMBER);
                    } else if (CellDenah[x][y].state == StateCell.JALUR2) {
                        blankCell(0);
                        CellDenah[x][y].state = StateCell.DESTINASI;
                        stateJenisCell[0][0] = x;
                        stateJenisCell[0][1] = y;
                        paintCell(x, y, Model.BORDER, Model.DESTINASI);
                    }
                } else if (e.getButton() == MouseButton.MIDDLE) {
                    stateCell = StateCell.BLOCK;
                    warna = !(warna);

                    if (warna && CellDenah[x][y].state != StateCell.SUMBER && CellDenah[x][y].state != StateCell.DESTINASI) {
                        paintCell(x, y, Model.BORDER, Model.BLOCK);
                        CellDenah[x][y].state = StateCell.BLOCK;
                    }

                }
            }

        });

        CellDenah[x][y].state = StateCell.BLANK; //default
    }

    private void blankCell(int row) {
        if (stateJenisCell[row][0] != -1) {
            paintCell(stateJenisCell[row][0], stateJenisCell[row][1], Model.BORDER, Model.BLANK);
            CellDenah[stateJenisCell[row][0]][stateJenisCell[row][1]].state = StateCell.BLANK;
            CellDenah[stateJenisCell[row][0]][stateJenisCell[row][1]].count = Model.JUMLAH;

        }
    }

    //gambar rute
    public synchronized static void paintCell(int x, int y, String border, String background) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (background == Model.SUMBER || background == Model.DESTINASI || background == Model.HUMAN ) {
                    BorderCell[x][y].setStyle("-fx-border-color: " + border + "; -fx-background-image: url('" + background + "')" + ";"
                            + "-fx-background-position: center center; "
                            + "-fx-background-size: cover");
                } else {
                    BorderCell[x][y].setStyle("-fx-border-color: " + border + "; -fx-background-color: " + background + ";");
                }

            }
        });
    }

    private void resetCell() {
        for (int x = 0; x < Model.ROW; x++) {
            for (int y = 0; y < Model.COL; y++) {

                CellDenah[x][y].setParent(-1, -1);
                CellDenah[x][y].distance = Integer.MAX_VALUE;

                if (CellDenah[x][y].state != StateCell.BLOCK) {
                    paintCell(x, y, Model.BORDER, Model.BLANK);
                    CellDenah[x][y].state = StateCell.BLANK;
                }

            }
        }
        paintCell(stateJenisCell[0][0], stateJenisCell[0][1], Model.BORDER, Model.SUMBER);
        paintCell(stateJenisCell[1][0], stateJenisCell[1][1], Model.BORDER, Model.DESTINASI);

        CellDenah[stateJenisCell[0][0]][stateJenisCell[0][1]].state = StateCell.SUMBER;
        CellDenah[stateJenisCell[1][0]][stateJenisCell[1][1]].state = StateCell.DESTINASI;
    }

    @FXML
    public void startBtnEvent(ActionEvent actionEvent) {

        if (Model.currentThread == null && stateJenisCell[0][0] != -1 && stateJenisCell[1][0] != -1) {
            state = false;
            warna = false;
            stateCell = null;
            Test algorithm = null;
            resetCell();
            algorithm = new BreadthFirst();
            Model.currentThread = algorithm;
            algorithm.initialize(CellDenah[stateJenisCell[0][0]][stateJenisCell[0][1]], CellDenah[stateJenisCell[1][0]][stateJenisCell[1][1]]);
            algorithm.start();

        } else {
            state = true;
        }
    }

    @FXML
    public void mazeBtnEvent(ActionEvent actionEvent) {
        state = true;
        stateJenisCell[1][0] = -1;
        Labirin labirin = new Labirin();
        labirin.start();
        System.out.println("Proses Pembuatan Labirin Berhenti");
        labirin.interrupt();
    }
}
