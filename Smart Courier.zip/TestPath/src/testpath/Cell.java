/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

/**
 *
 * @author USER
 */
public class Cell {
    public int x, y;
    public int distance;
    public int parent_x, parent_y;
    public int count;

    public StateCell state;

    public Cell(int x, int y)
    {
        this.x = x;
        this.y = y;
        state = StateCell.BLANK;
        this.distance = Integer.MAX_VALUE;
        this.count = 0;
    }

    public void setParent(int x, int y)
    {
        this.parent_x = x;
        this.parent_y = y;
    }

}
