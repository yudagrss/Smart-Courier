/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

import java.util.Arrays;
import java.util.Random;
import java.util.Stack;

/**
 *
 * @author USER
 */
public class Labirin extends Thread {

    private static class Point {

        public final int X;
        public final int Y;

        public Point(int x, int y) {
            this.X = x;
            this.Y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            Point point = (Point) o;
            return X == point.X
                    && Y == point.Y;
        }
    }

    private static final int[] X = {0, 1, 0, -1};
    private static final int[] Y = {-1, 0, 1, 0};
    private static final Random random = new Random();

    private static int[] validDirections = new int[4];

    private static final int windingPercent = 100;

    public static boolean inRange(int r, int c) {
        return (r >= 1 && r < Model.ROW - 1) && (c >= 1 && c < Model.COL - 1);
    }

    private static Point getNeighbor(Point current, int direction) {
        int x = current.X + X[direction] * 2;
        int y = current.Y + Y[direction] * 2;
        if (inRange(x, y)) {
            return new Point(x, y);
        }

        return null;
    }

    private static boolean isValidNeighbor(int[][] maze, Point neighbor) {
        if (neighbor == null) {
            return false;
        }
        return maze[neighbor.X][neighbor.Y] == 0;
    }

    public static int[][] generateMaze() {

        // 0 - wall
        // 1 - path
        int[][] maze = new int[Model.ROW][Model.COL];
        Stack<Point> stack = new Stack<>();

        int lastDirection = -1;

        maze[1][1] = 1;
        stack.push(new Point(1, 1));
        while (!stack.isEmpty()) {
            Point current = stack.peek();
            Arrays.fill(validDirections, -1);
            // find valid neighbor
            int validDirectionCount = 0;
            boolean lastDirectionValid = false;
            for (int i = 0; i < Model.JUMLAH_SISI_CELL; i++) {
                Point neighbor = getNeighbor(current, i);
                if (isValidNeighbor(maze, neighbor)) {
                    validDirections[validDirectionCount++] = i;

                    if (lastDirection == i) {
                        lastDirectionValid = true;
                    }
                }
            }

            if (validDirectionCount > 0) {
                int chosenDirection;
                if (lastDirection != -1 && lastDirectionValid && random.nextInt(101) > windingPercent) {
                    chosenDirection = lastDirection;
                } else {
                    chosenDirection = validDirections[random.nextInt(validDirectionCount)];
                }

                Point tmp = getNeighbor(current, chosenDirection);
                maze[tmp.X - X[chosenDirection]][tmp.Y - Y[chosenDirection]] = 1;
                maze[tmp.X][tmp.Y] = 1;

                lastDirection = chosenDirection;
                stack.push(tmp);
            } else {
                stack.pop();
                lastDirection = -1;
            }
        }

        return maze;
    }

    @Override
    public void run() {
        int[][] maze = Labirin.generateMaze();
        for (int i = 0; i < Model.ROW; i++) {
            for (int j = 0; j < Model.COL; j++) {
                try {
                    if (maze[i][j] == 0) {
                        FXMLDocumentController.paintCell(i, j, Model.BORDER, Model.BLOCK);
                        FXMLDocumentController.CellDenah[i][j].state = StateCell.BLOCK;
                        Thread.sleep(Model.THREAD_SLEEP_TIME_LABIRIN);
                    } else {
                        FXMLDocumentController.paintCell(i, j, Model.BORDER, Model.BLANK);
                        FXMLDocumentController.CellDenah[i][j].state = StateCell.BLANK;
                    }
                } catch (Exception e) {
                    System.out.println("Thread terganggu");
                }
            }
        }
    }
}
