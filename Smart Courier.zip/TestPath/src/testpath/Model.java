/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

import javafx.scene.control.Button;

/**
 *
 * @author USER
 */
public class Model {

    //Cell
    public static int ROW = 25, COL = 13;
    public static int CELL_WIDTH = 20, CELL_HEIGHT = 20;

    //Cell Icon
    public static final String SUMBER = "/Icons/source.png";
    public static final String HUMAN = "/Icons/human.png";
    public static final String DESTINASI = "/Icons/target.png";
    
    //Cell Color
    public static final String BLANK = "#fffff0";
    public static final String BORDER = "black";
    public static final String BLOCK = "#202040";
    public static final String JALUR = "yellow"; // "#fbcffc";
    public static final String JALUR2 = "yellow"; //"ff9a76"; //"#b4de87";
    public static final String RUTE_JALUR = "#00dc00";

    //Algorithma
    public static int THREAD_SLEEP_TIME = 100;
    public static int THREAD_SLEEP_TIME_LABIRIN = 10;
    public static final int JUMLAH_SISI_CELL = 4;
    public static final int JUMLAH = 0;
    public static Test currentThread = null;

}
