/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

/**
 *
 * @author USER
 */
public enum StateCell {
    BLANK,
    JALUR,
    JALUR2,
    BLOCK,
    RUTE_JALUR,
    DESTINASI,
    SUMBER
}
