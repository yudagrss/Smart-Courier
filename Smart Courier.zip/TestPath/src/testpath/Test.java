/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testpath;

import java.util.LinkedList;
import static testpath.Model.*;
import testpath.FXMLDocumentController.*;

/**
 *
 * @author USER
 */
public class Test extends Thread {

    static boolean state = true;
    // nilai offset untuk sumber cell (seluruh sisi cell)
    public static int[] X = {0, 1, 0, -1};
    public static int[] Y = {-1, 0, 1, 0};

    protected Cell sumber;
    protected Cell destinasi;

    protected boolean stateJalur;
    protected int ruteJalur;

    public void initialize(Cell sumber, Cell destinasi) {
        this.sumber = sumber;
        this.destinasi = destinasi;
        stateJalur = false;
        ruteJalur = Integer.MAX_VALUE;
    }

    public boolean inRange(int r, int c) {
        return (r >= 0 && r < Model.ROW) && (c >= 0 && c < Model.COL);
    }

    protected void colorPath(LinkedList<Cell> shortestPath, String color, boolean isShortest) {
        Cell a = null, b = null;// a = sebelum, b = saat ini
        for (Cell cell : shortestPath) {
            a = cell;
            if (!isShortest) { // mengubah state ke JALUR state
                FXMLDocumentController.paintCell(a.x, a.y, Model.BORDER, color);
                FXMLDocumentController.CellDenah[a.x][a.y].state = StateCell.JALUR;
                b = a;
            } else {
                if (b != null) { //membuat sumber cell beralih ke destinasi cell
                    FXMLDocumentController.paintCell(b.x, b.y, Model.BORDER, color);
                }
                FXMLDocumentController.paintCell(a.x, a.y, Model.BORDER, Model.HUMAN);
                a.state = StateCell.RUTE_JALUR;

                b = a;
                try {
                    FXMLDocumentController.CellDenah[a.x][a.y].state = StateCell.RUTE_JALUR;
                    Thread.sleep(Model.THREAD_SLEEP_TIME);
                } catch (Exception e) {
                    System.out.println("Thread terganggu");
                }
            }
        }

        //repaint cell rute jalur
        if (b != null) {
            FXMLDocumentController.paintCell(b.x, b.y, Model.BORDER, Model.DESTINASI);
        }
    }

    public void stopThread() {
        System.out.println("Thread dihentikan");
        stateJalur = true;
        this.interrupt();
        Model.currentThread = null;
        state = true;
        System.out.println("test " + state);
    }

    public static boolean getstate() {
        return state;
    }

}
